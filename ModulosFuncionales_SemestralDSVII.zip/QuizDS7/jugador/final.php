<?php
require_once __DIR__ . '/../config/baseDatosConfig.php';
require_once __DIR__ . '/../controllers/JuegoController.php';

$db = new DB();
$controller = new JuegoController($db);

// Luego según la vista:
$controller->index(); // o jugar(), final()
include __DIR__ . '/../views/finalJuegoView.php';
