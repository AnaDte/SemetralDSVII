<?php
require_once __DIR__ . '/../controllers/PreguntaController.php';
$controller = new PreguntaController();
$controller->handleRequest();
include __DIR__ . '/../views/nuevaPreguntaView.php';
?>