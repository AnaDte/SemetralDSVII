<?php
require_once __DIR__ . '/../config/baseDatosConfig.php';

//Función para obtener el registro de la configuración del sitio
function obtenerConfiguracion() {
    $db = new DB();
    $sql = "SELECT COUNT(*) AS total FROM config";
    $stmt = $db->getConexion()->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row['total'] == '0') {
        $sql = "INSERT INTO config (id,usuario,password,totalPreguntas) VALUES (NULL, 'admin', 'admin','3')";
        $db->conexion->exec($sql);
    }

    $sql = "SELECT * FROM config WHERE id='1'";
    $stmt = $db->getConexion()->prepare($sql);
    $stmt->execute();
    $config = $stmt->fetch(PDO::FETCH_ASSOC);
    return $config;
}

function aumentarVisita() {
    $db = new DB();
    $sql = "UPDATE estadisticas SET visitas = visitas + 1 WHERE id='1'";
    $db->getConexion()->exec($sql);
}

function aumentarRespondidas() {
    $db = new DB();
    $sql = "UPDATE estadisticas SET respondidas = respondidas + 1 WHERE id='1'";
    $db->conexion->exec($sql);
}

function aumentarCompletados() {
    $db = new DB();
    $sql = "UPDATE estadisticas SET completados = completados + 1 WHERE id='1'";
    $db->getConexion()->exec($sql);
}