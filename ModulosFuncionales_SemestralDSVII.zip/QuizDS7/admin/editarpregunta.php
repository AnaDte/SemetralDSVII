<?php
require_once __DIR__ . '/../config/baseDatosConfig.php';
require_once __DIR__ . '/../controllers/EditarPreguntaController.php';

$db = new DB();
$controller = new EditarPreguntaController($db);
$controller->handleRequest();

include __DIR__ . '/../views/editarPreguntaView.php';