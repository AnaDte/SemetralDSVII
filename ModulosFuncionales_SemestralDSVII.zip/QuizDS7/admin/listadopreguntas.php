<?php
require_once __DIR__ . '/../config/baseDatosConfig.php';
require_once __DIR__ . '/../controllers/ListaController.php';
$db = new DB();
$controller = new PreguntaListController($db);
$controller->handleRequest();
include __DIR__ . '/../views/listadoPreguntasView.php';
?>