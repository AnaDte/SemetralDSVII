<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Perfil de Usuario</title>
    <link rel="stylesheet" href="../css/estiloJuego.css">
</head>
<body>
    <a href="../jugador/index.php" class="btn-volver-menu-fixed">&#8592; Regresar al Menú</a>
    <div class="perfil-container">
        <h2>Mi Perfil</h2>
        <?php if ($controller->mensaje): ?>
            <div class="mensaje"><?php echo $controller->mensaje; ?></div>
        <?php endif; ?>
        <form action="" method="post" enctype="multipart/form-data">
            <img src="../<?php echo $controller->usuario['avatar'] ?? 'img/avatares/avatarDefault.jpg'; ?>" alt="Avatar" style="width:120px;height:120px;border-radius:50%;">
            <div>
                <label>Subir nueva imagen:</label>
                <input type="file" name="avatar" accept="image/*">
            </div>
            <div>
                <label>O elegir avatar por defecto:</label>
                <div class="avatar-options">
                    <label>
                        <input type="radio" name="avatar_default" value="img/avatares/avatar2.webp"
                            <?php if (($controller->usuario['avatar'] ?? '') == 'img/avatares/avatar2.webp') echo 'checked'; ?>>
                        <img src="../img/avatares/avatar2.webp" alt="Avatar 2" class="avatar-img-option">
                    </label>
                    <label>
                        <input type="radio" name="avatar_default" value="img/avatares/avatar2.png"
                            <?php if (($controller->usuario['avatar'] ?? '') == 'img/avatares/avatar2.png') echo 'checked'; ?>>
                        <img src="../img/avatares/avatar2.png" alt="Avatar 1" class="avatar-img-option">
                    </label>
                    <!-- Agrega más avatares si tienes más imágenes -->
                </div>
            </div>
            <div>
                <label>Nombre:</label>
                <input type="text" name="nombre" value="<?php echo htmlspecialchars($controller->usuario['nombre'] ?? ''); ?>">
            </div>
            <div>
                <label>Apellido:</label>
                <input type="text" name="apellido" value="<?php echo htmlspecialchars($controller->usuario['apellido'] ?? ''); ?>">
            </div>
            <div>
                <label>Usuario:</label>
                <input type="text" name="usuario" value="<?php echo htmlspecialchars($controller->usuario['usuario'] ?? ''); ?>" readonly>
            </div>
            <div>
                <label>Correo:</label>
                <input type="email" name="correo" value="<?php echo htmlspecialchars($controller->usuario['correo'] ?? ''); ?>">
            </div>
            <div>
                <label>Nueva clave:</label>
                <input type="password" name="clave">
            </div>
            <input type="submit" value="Actualizar Perfil">
        </form>
    </div>
</body>
</html>