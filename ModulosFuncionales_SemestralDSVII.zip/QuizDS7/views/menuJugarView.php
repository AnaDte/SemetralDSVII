<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer"/>
    <link rel="stylesheet" href="../css/estiloJuego.css">
    <title>QUIZ GAME</title>
</head>
<body>
    <!-- Perfil fuera del contenedor -->
    <div class="perfil-jugador-externo">
        <i class="fa fa-user"></i>
        <span>
            <?php echo isset($_SESSION['usuario']) ? htmlspecialchars($_SESSION['usuario']) : 'Invitado'; ?>
        </span>
        <a href="../jugador/perfil.php" class="btn-perfil" style="margin-left:10px;">Ver Perfil</a>
    </div>
    <!-- Estadísticas fuera del contenedor -->
    <div class="estadisticas-jugador-externo">
        <a href="../jugador/estadisticas.php" class="btn-estadisticas" style="margin-left:10px;">
            <i class="fa fa-chart-bar"></i> Estadísticas
        </a>
    </div>

    <div class="container" id="cantainer">
        <div class="left">
            <div class="bienvenida" style="margin-top: 60px;">
                <h2>¡PON A PRUEBA TUS CONOCIMIENTOS!<br><br></h2>
            </div>
        </div>
        <div class="right">
            <h3 style="text-align:center;">Elige una categoría</h3>
            <div class="categorias">
                <?php foreach ($controller->categorias as $cat): ?>
                <div class="categoria">
                    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" id="cat_<?php echo $cat['id']; ?>" method="get">
                        <input type="hidden" name="idCategoria" value="<?php echo $cat['id']; ?>">
                        <a href="javascript:{}" onclick="document.getElementById('cat_<?php echo $cat['id']; ?>').submit(); return false;">
                            <?php echo htmlspecialchars($cat['nombre']); ?>
                        </a>
                    </form>
                </div>
                <?php endforeach ?>
            </div>
        </div>
        <footer></footer>
    </div>
</body>
</html>
