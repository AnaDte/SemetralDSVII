<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/estiloAdmin.css">
    <title>Modificar Pregunta</title>
</head>
<body>
    <div class="contenedor">
        <header>
            <h1>QUIZ GAME</h1>
        </header>
        <div class="contenedor-info">
            <?php include("nav.php") ?>
            <div class="panel">
                <h2>Modificar Pregunta</h2>
                <hr>
                <section id="nuevaPregunta">
                    <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="get">
                        <input type="hidden" name="idPregunta" value = "<?php echo $controller->pregunta['id'] ?>">
                        <div class="fila">
                            <label for="">Tema: </label>
                            <select name="tema" id="tema">
                                <?php foreach ($controller->temas as $row): ?>
                                    <option value="<?php echo $row['id'] ?>" <?php if ($row['id'] == $controller->pregunta['tema']) echo "selected"; ?>>
                                        <?php echo $row['nombre'] ?>
                                    </option>
                                <?php endforeach ?>
                            </select>
                        </div>
                        <div class="fila">
                            <label for="">Pregunta:</label>
                            <textarea name="pregunta" cols="30" rows="10" required><?php echo $controller->pregunta['pregunta']?></textarea>
                        </div>
                        <div class="opciones">
                            <div class="opcion">
                                <label for="">Opcion A</label>
                                <input type="text" name="opcion_a" value = "<?php echo $controller->pregunta['opcion_a']?>" required>
                            </div>
                            <div class="opcion">
                                <label for="">Opcion B</label>
                                <input type="text" name="opcion_b" value ="<?php echo $controller->pregunta['opcion_b']?>" required>
                            </div>
                            <div class="opcion">
                                <label for="">Opcion C</label>
                                <input type="text" name="opcion_c" value="<?php echo $controller->pregunta['opcion_c']?>">
                            </div>
                        </div>
                        <div class="opcion">
                            <label for="">Correcta</label>
                            <select name="correcta" class="correcta">
                                <option value="A" <?php if($controller->pregunta['correcta']=='A'){ echo "selected";}?>>A</option>
                                <option value="B" <?php if($controller->pregunta['correcta']=='B'){ echo "selected";}?>>B</option>
                                <option value="C" <?php if($controller->pregunta['correcta']=='C'){ echo "selected";}?>>C</option>
                            </select>
                        </div>
                        <hr>
                        <input type="submit" value="Actualizar Pregunta" name="actualizar" class="btn-guardar">
                    </form>
                </section>
            </div>
        </div>
    </div>

    <!-- Ventana Modal para nuevo Tema -->
    <div id="modalTema" class="modal">
        <div class="modal-content">
            <span class="close" onclick="cerrarTema()">&times;</span>
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="get">
                <label for="">Agregar Nuevo Tema</label>
                <input type="text" name="nombreTema" required>
                <input type="submit" name="nuevoTema" value="Guardar Tema" class="btn">
            </form>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>