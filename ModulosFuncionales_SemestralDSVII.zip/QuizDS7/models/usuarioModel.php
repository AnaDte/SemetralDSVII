<?php // models/usuarioModel.php

class Usuario { 

    private $cedula;
    private $nombre;
    private $apellido;
    private $usuario; // apodo corto
    private $correo;  // login
    private $clave;   // registro/clave
    private $rol;     //operador o jugador //ANA DICE QUE ASI NO ES. DICE QUE NO PERO SI LO DIJO.
    private $estado;  // activo (default) o inactivo
    private $hash;    // clave hasheada
    private $puntos;  // 0 (default)
    private $avatar;  // foto seleccionada en el sistema
    private $pdo;     // instancia bd
    private $tabla;   // tabla bd

    public function __construct($pdo) { 
        $this->pdo = $pdo; // conexion a la bd
        $this->tabla = "usuario"; // tabla bd de la clase
    }

    // registrar un nuevo usuario en la bd
    public function registrarUsuario(){
        $data = array(
            "cedula"   => $this->cedula,
            "nombre"   => $this->nombre,
            "apellido" => $this->apellido,
            "usuario"  => $this->usuario,
            "correo"   => $this->correo,
            "clave"    => $this->clave,
            "rol"      => $this->rol
        );
        return $this->pdo->insertSeguro($this->tabla, $data);
    }

    // Actualiza un usuario en la bd
    public function actualizarUsuario() {
        $data = array(
            "cedula"   => $this->cedula,
            "nombre"   => $this->nombre,
            "apellido" => $this->apellido,
            "usuario"  => $this->usuario,
            "correo"   => $this->correo,
            "clave"    => $this->clave,
            "rol"      => $this->rol,
            "estado"   => $this->estado,
            "avatar"   => $this->avatar,
        );

        $condiciones = array("cedula" => $this->cedula);
        return $this->pdo->updateSeguro($this->tabla, $data, $condiciones);
    }

     public function setRequiredFields(array $fields) {
        $this->requiredFields = $fields;
    }

    public function validate() {
        $this->Errores = [];
    
        foreach ($this->requiredFields as $campo) {
            $valor = $this->$campo;
    
            // Verifica que el campo no esté vacío
            if (empty($valor)) {
                $this->Errores[$campo] = "El campo $campo es obligatorio.";
                continue;
            }
    
            switch ($campo) {
                case 'cedula':
                    if (!SanitizarEntrada::validarDescripcion($valor)) {
                        $this->Errores[$campo] = "La cédula no tiene un formato válido.";
                    }
                    break;
    
                case 'nombre':
                case 'apellido':
                    if (!SanitizarEntrada::validarDescripcion($valor)) {
                        $this->Errores[$campo] = "El $campo solo debe contener letras y espacios.";
                    }
                    break;
    
                case 'usuario':
                    if (!SanitizarEntrada::validarUsuario($valor)) {
                        $this->Errores[$campo] = "El usuario debe ser alfanumérico sin espacios.";
                    }
                    break;
    
                case 'correo':
                    if (!SanitizarEntrada::validarCorreo($valor)) {
                        $this->Errores[$campo] = "El correo electrónico no es válido.";
                    }
                    break;
    
                case 'clave':
                    if (!SanitizarEntrada::validarClave($valor)) {
                        $this->Errores[$campo] = "La clave debe tener al menos 6 caracteres.";
                    }
                    break;
    
                case 'rol':
                    if (!in_array($valor, ['operador', 'jugador'])) {
                        $this->Errores[$campo] = "El rol debe ser 'operador' o 'jugador'.";
                    }
                    break;
    
                case 'estado':
                    if (!in_array($valor, ['activo', 'inactivo'])) {
                        $this->Errores[$campo] = "El estado debe ser 'activo' o 'inactivo'.";
                    }
                    break;
            }
        }
    }
    

// Recibe datos en forma de arreglo y los asigna a las propiedades
public function RecibirDatos($data) {
    $this->cedula   = $data['cedula']   ?? '';
    $this->nombre   = $data['nombre']   ?? '';
    $this->apellido = $data['apellido'] ?? '';
    $this->usuario  = $data['usuario']  ?? '';
    $this->correo   = $data['correo']   ?? '';
    $this->clave    = $data['clave']    ?? '';
    $this->rol      = $data['rol']      ?? '';
    $this->estado   = $data['estado']   ?? '';
}


// Normaliza los datos recibidos a tipos adecuados para almacenar
public function RegistrarDatos() {
    $this->cedula   = trim($this->cedula);
    $this->nombre   = ucwords(strtolower(trim($this->nombre)));
    $this->apellido = ucwords(strtolower(trim($this->apellido)));
    $this->usuario  = strtolower(trim($this->usuario));
    $this->correo   = strtolower(trim($this->correo));
    $this->clave    = trim($this->clave); // Aquí podrías hashearla si es necesario
    $this->rol      = strtolower(trim($this->rol));
    $this->estado   = strtolower(trim($this->estado));
}

public function hashearClave() {
    $this->clave = password_hash($this->clave, PASSWORD_DEFAULT);
}

// Busca productos usando varios campos para la búsqueda con OR
public function buscarUsuarioMultiplesCampos($busqueda = "") {
     $campos = ['cedula', 'nombre', 'apellido', 'usuario', 'correo', 'clave', 'rol']; 
    return $this->pdo->selectSeguroMultiple($this->tabla, ['cedula', 'nombre', 'apellido', 'usuario', 'correo', 'clave', 'rol'], $campos, $busqueda);
}

// designa avatar 
public function setAvatar($ruta) {
    $this->avatar = $ruta;
}
} 

?>