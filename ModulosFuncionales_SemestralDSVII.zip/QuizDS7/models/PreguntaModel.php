<?php
class PreguntaModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function agregarPregunta($data) {
        if ($data['tipo_pregunta'] === 'cierto_falso') {
            $opcion_a = 'Cierto';
            $opcion_b = 'Falso';
            $opcion_c = null;
        } else {
            $opcion_a = htmlspecialchars($data['opcion_a']);
            $opcion_b = htmlspecialchars($data['opcion_b']);
            $opcion_c = htmlspecialchars($data['opcion_c']);
        }

        // Construir el array de datos para insertSeguro
        $insertData = [
            'tema' => $data['tema'],
            'pregunta' => $data['pregunta'],
            'tipo' => $data['tipo_pregunta'],
            'opcion_a' => $opcion_a,
            'opcion_b' => $opcion_b,
            'correcta' => $data['correcta'],
            'dificultad' => $data['dificultad']
        ];
        if ($opcion_c !== null) {
            $insertData['opcion_c'] = $opcion_c;
        }

        $ok = $this->db->insertSeguro('preguntas', $insertData);
        if ($ok) {
            return "La pregunta se insertó correctamente";
        } else {
            return "Error al insertar la pregunta";
        }
    }

     public function obtenerTodasLasPreguntas() {
        $sql = "SELECT * FROM preguntas";
        $stmt = $this->db->getConexion()->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPreguntasFiltradas($tema = null, $dificultad = null) {
        $sql = "SELECT * FROM preguntas WHERE 1=1";
        $params = [];
        if (!empty($tema)) {
            $sql .= " AND tema = :tema";
            $params[':tema'] = $tema;
        }
        if (!empty($dificultad)) {
            $sql .= " AND dificultad = :dificultad";
            $params[':dificultad'] = $dificultad;
        }
        $stmt = $this->db->getConexion()->prepare($sql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerCategoriasTemas() {
    $sql = "SELECT * FROM temas COUNT(DISTINCT tema) FROM preguntas GROUP BY tema";
    $stmt = $db->getConexion()->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function actualizarPregunta($data) {
        $sql = "UPDATE preguntas SET tema = :tema, pregunta = :pregunta, opcion_a = :opcion_a, opcion_b = :opcion_b, opcion_c = :opcion_c, correcta = :correcta WHERE id = :id";
        $stmt = $this->db->getConexion()->prepare($sql);
        $stmt->bindValue(':tema', $data['tema']);
        $stmt->bindValue(':pregunta', $data['pregunta']);
        $stmt->bindValue(':opcion_a', $data['opcion_a']);
        $stmt->bindValue(':opcion_b', $data['opcion_b']);
        $stmt->bindValue(':opcion_c', $data['opcion_c']);
        $stmt->bindValue(':correcta', $data['correcta']);
        $stmt->bindValue(':id', $data['id']);
        return $stmt->execute();
    }

    public function obtenerPreguntaPorId($id) {
        $sql = "SELECT * FROM preguntas WHERE id = :id";
        $stmt = $this->db->getConexion()->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerIdsPreguntasPorCategoria($tema) {
        $sql = "SELECT id FROM preguntas WHERE tema = :tema";
        $stmt = $this->db->getConexion()->prepare($sql);
       $stmt->bindValue(':tema', $tema, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

}
?>