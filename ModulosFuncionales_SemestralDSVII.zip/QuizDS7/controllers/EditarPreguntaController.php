<?php
require_once __DIR__ . '/../models/PreguntaModel.php';
require_once __DIR__ . '/../models/TemaModel.php';

class EditarPreguntaController {
    public $pregunta;
    public $temas;
    public $mensaje = null;

    private $preguntaModel;
    private $temaModel;

    public function __construct($db) {
        $this->preguntaModel = new PreguntaModel($db);
        $this->temaModel = new TemaModel($db);
    }

    public function handleRequest() {
        session_start();
        if (!$_SESSION['usuarioLogeado']) {
            header("Location:login.php");
            exit;
        }

        // Actualizar pregunta
        if (isset($_GET['actualizar'])) {
            $data = [
                'id' => $_GET['idPregunta'],
                'tema' => $_GET['tema'],
                'pregunta' => htmlspecialchars($_GET['pregunta']),
                'opcion_a' => htmlspecialchars($_GET['opcion_a']),
                'opcion_b' => htmlspecialchars($_GET['opcion_b']),
                'opcion_c' => htmlspecialchars($_GET['opcion_c']),
                'correcta' => $_GET['correcta']
            ];
            if ($this->preguntaModel->actualizarPregunta($data)) {
                header("Location: listadopreguntas.php");
                exit;
            } else {
                $this->mensaje = "No se pudo actualizar la pregunta";
            }
        }

        // Obtener pregunta por ID
        $id = $_GET['idPregunta'] ?? null;
        if ($id) {
            $this->pregunta = $this->preguntaModel->obtenerPreguntaPorId($id);
        }

        // Obtener todos los temas
        $this->temas = $this->temaModel->obtenerTodos();

        // Nuevo tema
        if (isset($_GET['nuevoTema'])) {
            $nombreTema = $_GET['nombreTema'];
            if ($this->temaModel->agregar($nombreTema)) {
                header("Location: nuevapregunta.php");
                exit;
            } else {
                $this->mensaje = "No se pudo agregar el tema";
            }
        }
    }
}
?>