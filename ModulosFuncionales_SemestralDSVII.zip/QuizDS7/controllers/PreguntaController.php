<?php
include_once __DIR__ . '/../models/PreguntaModel.php';
include_once __DIR__ . '/../models/TemaModel.php';

class PreguntaController {
    public $mensaje = null;
    public $temas = null;
    public $model;

    public function handleRequest() {
        session_start();
        if (!$_SESSION['usuarioLogeado']) {
            header("Location:login.php");
            exit;
        }

        require_once __DIR__ . '/../config/baseDatosConfig.php';
        $db = new DB(); // instancia válida

        $this->model = new PreguntaModel($db);

        // CORREGIDO: obtener temas desde el modelo correcto
        $temaModel = new TemaModel($db);
        $this->temas = $temaModel->obtenerTodos();

        if (isset($_GET['guardar'])) {
            $data = [
                'pregunta' => $_GET['pregunta'],
                'tema' => $_GET['tema'],
                'correcta' => $_GET['correcta'],
                'tipo_pregunta' => $_GET['tipo_pregunta'],
                'dificultad' => $_GET['dificultadN'],
                'opcion_a' => $_GET['opcion_a'] ?? null,
                'opcion_b' => $_GET['opcion_b'] ?? null,
                'opcion_c' => $_GET['opcion_c'] ?? null
            ];
            $this->mensaje = $this->model->agregarPregunta($data);
        }

        if (isset($_POST['nuevoTema']) && !empty($_POST['nombreTema'])) {
            $nombre = trim($_POST['nombreTema']);
            if ($temaModel->agregarTema($nombre)) {
            $this->mensaje = "Tema agregado correctamente";
            // Redirigir para evitar reinserción al refrescar
            header("Location: ../admin/nuevapregunta.php");
            exit;
        } else {
            $this->mensaje = "Error al agregar el tema";
            }
        }
    }
}
?>
