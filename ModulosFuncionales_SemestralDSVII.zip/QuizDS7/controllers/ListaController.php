<?php
include_once __DIR__ . '/../models/PreguntaModel.php';
include_once __DIR__ . '/../models/TemaModel.php';

class PreguntaListController {
    public $resultado_preguntas;
    public $temas;
    private $preguntaModel;
    private $temaModel;
    public $tema;        
    public $dificultad;  

    public function __construct($db) {
        $this->preguntaModel = new PreguntaModel($db);
        $this->temaModel = new TemaModel($db); // importante
    }

    public function handleRequest() {
        session_start();
        if (!$_SESSION['usuarioLogeado']) {
            header("Location:login.php");
            exit;
        }

        $tema = $_GET['tema'] ?? null;
        $dificultad = $_GET['dificultad'] ?? null;

        if ($tema || $dificultad) {
            $this->resultado_preguntas = $this->preguntaModel->obtenerPreguntasFiltradas($tema, $dificultad);
        } else {
            $this->resultado_preguntas = $this->preguntaModel->obtenerTodasLasPreguntas();
        }

        // Ahora sí usamos correctamente TemaModel
        $this->temas = $this->temaModel->obtenerTodos();

        $this->tema = $tema;
        $this->dificultad = $dificultad;
    }
}
?>
