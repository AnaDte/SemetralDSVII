<?php

include_once __DIR__ . '/../models/TemaModel.php';
include_once __DIR__ . '/../models/PreguntaModel.php';

class JuegoController {
    public $mensaje = null;
    public $categorias = [];
    public $preguntaActual = null;
    public $totalPreguntasPorJuego = 0;
    private $juegoModel;
    private $temaModel;
    private $preguntaModel;

    public function __construct($db) {
        
        $this->temaModel = new TemaModel($db);
        $this->preguntaModel = new PreguntaModel($db);
    }

    public function index() {
        session_start();
        $this->categorias = $this->temaModel->obtenerTodos();

        if (isset($_GET['idCategoria'])) {
            $_SESSION['usuario'] = "usuario";
            $_SESSION['idCategoria'] = $_GET['idCategoria'];
            header("Location: jugar.php");
            exit;
        }
    }

    public function jugar() {
    session_start();

    if (!isset($_SESSION['idCategoria'])) {
        header("Location: index.php");
        exit;
    }

    // 💡 Asegurarse de que totalPreguntas esté definido correctamente
    if (!isset($_SESSION['idPreguntas'])) {
        $_SESSION['idPreguntas'] = $this->preguntaModel->obtenerIdsPreguntasPorCategoria($_SESSION['idCategoria']);
        shuffle($_SESSION['idPreguntas']);
    }

    $this->totalPreguntasPorJuego = count($_SESSION['idPreguntas']);

    if (isset($_GET['siguiente'])) {
        if ($_SESSION['respuesta_correcta'] == $_GET['respuesta']) {
            $_SESSION['correctas']++;
        }

        $_SESSION['numPreguntaActual']++;

        if ($_SESSION['numPreguntaActual'] < $this->totalPreguntasPorJuego) {
            $this->preguntaActual = $this->preguntaModel->obtenerPreguntaPorId(
                $_SESSION['idPreguntas'][$_SESSION['numPreguntaActual']]
            );
            $_SESSION['respuesta_correcta'] = $this->preguntaActual['correcta'];
        } else {
            $_SESSION['incorrectas'] = $this->totalPreguntasPorJuego - $_SESSION['correctas'];
            $_SESSION['nombreCategoria'] = $this->temaModel->obtenerNombreTema($_SESSION['idCategoria']);
            $_SESSION['score'] = ($_SESSION['correctas'] * 100) / $this->totalPreguntasPorJuego;

            header("Location: final.php");
            exit;
        }
    } else {
        // Primera pregunta
        $_SESSION['correctas'] = 0;
        $_SESSION['numPreguntaActual'] = 0;

        // Ya se cargó arriba y se hizo shuffle
        $this->preguntaActual = $this->preguntaModel->obtenerPreguntaPorId($_SESSION['idPreguntas'][0]);
        
        $_SESSION['respuesta_correcta'] = $this->preguntaActual['correcta'];
    }
  }
}