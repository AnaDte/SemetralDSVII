<?php
require_once __DIR__ . '/../models/usuarioModel.php';

class GestionarPerfilController {
    public $usuario;
    public $mensaje = null;
    private $usuarioModel;

    public function __construct($pdo) {
        $this->usuarioModel = new Usuario($pdo);
    }

    public function mostrarPerfil($usuarioId) {
        // Supón que el usuario está logueado y su id está en $_SESSION['usuario']
        $this->usuario = $this->usuarioModel->buscarUsuarioMultiplesCampos($usuarioId)[0] ?? null;
    }

    public function actualizarPerfil($data, $file) {
        $this->usuarioModel->RecibirDatos($data);
        $this->usuarioModel->RegistrarDatos();

        // Manejo de imagen de perfil
        if (isset($file['avatar']) && $file['avatar']['error'] == 0) {
            $nombreArchivo = uniqid() . '_' . basename($file['avatar']['name']);
            $rutaDestino = __DIR__ . '/../img/avatares/' . $nombreArchivo;
            if (move_uploaded_file($file['avatar']['tmp_name'], $rutaDestino)) {
                $this->usuarioModel->setAvatar('img/avatares/' . $nombreArchivo);
            }
        } elseif (isset($data['avatar_default'])) {
            $this->usuarioModel->setAvatar($data['avatar_default']);
        }

        if (!empty($data['clave'])) {
            $this->usuarioModel->hashearClave();
        }

        if ($this->usuarioModel->actualizarUsuario()) {
            $this->mensaje = "Perfil actualizado correctamente.";
        } else {
            $this->mensaje = "Error al actualizar el perfil.";
        }
    }
}
?>